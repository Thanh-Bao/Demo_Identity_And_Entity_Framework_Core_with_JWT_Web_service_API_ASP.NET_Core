﻿using JWTAuthentication.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Google.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class ProtectedValueController : ControllerBase
    {

        [Authorize(Roles = UserRoles.Admin)]
        [Route("admin-resource")]
        [HttpGet]
        public string Admin()
        {
            return " test chỉ Admin mới thấy";
        }

        [Authorize(Roles = UserRoles.User + "," + UserRoles.Admin)]
        [Route("user-resource")]
        [HttpPost]
        public string User123()
        {
            return "test chỉ User và admin mới thấy";
        }

    }
}
